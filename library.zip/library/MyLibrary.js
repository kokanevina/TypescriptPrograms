"use strict";
// MyLibrary.ts : Module : MyLibrary
exports.__esModule = true;
exports.MyBook = exports.changeLibrary = exports.libraryName = void 0;
exports.libraryName = 'BackEnd Technologies';
function changeLibrary(lname) {
    exports.libraryName = lname;
}
exports.changeLibrary = changeLibrary;
var MyBook = /** @class */ (function () {
    function MyBook(id, name, price) {
        this.bookId = id;
        this.bookName = name;
        this.bookPrice = price;
    }
    MyBook.prototype.getDetails = function () {
    };
    return MyBook;
}());
exports.MyBook = MyBook;
