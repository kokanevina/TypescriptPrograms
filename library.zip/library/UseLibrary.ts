import {libraryName, changeLibrary as setLib, MyBook} from './MyLibrary';
import colName from './CollegeLibrary'; // use any varname , do not curly braces
import {Department} from './CollegeLibrary';
import * as Uni from './University'; // prefix
console.log(libraryName);
//libraryName="Server Technologies"; //can not directly change
setLib("Server Technologies");
let book1=new MyBook(567,'javatech',780);
book1.getDetails();
console.log(colName);
let dept=new Department();
let u=new Uni.University();
let l=new Uni.Location();

