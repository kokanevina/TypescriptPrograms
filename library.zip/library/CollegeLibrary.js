"use strict";
exports.__esModule = true;
exports.Department = void 0;
var collegeName = "LT college";
var Department = /** @class */ (function () {
    function Department() {
    }
    return Department;
}());
exports.Department = Department;
exports["default"] = collegeName;
