// MyLibrary.ts : Module : MyLibrary

export let libraryName='BackEnd Technologies';

export function changeLibrary(lname:string){
    libraryName=lname;
}
export class MyBook{
    bookId:number;
    bookName:string;
    bookPrice:number;

    constructor(id:number,name:string,price:number){
        this.bookId=id;
        this.bookName=name;
        this.bookPrice=price;
    }
    getDetails(){
    }
}