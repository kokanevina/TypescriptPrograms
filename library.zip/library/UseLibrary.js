"use strict";
exports.__esModule = true;
var MyLibrary_1 = require("./MyLibrary");
var CollegeLibrary_1 = require("./CollegeLibrary");
console.log(MyLibrary_1.libraryName);
//libraryName="Server Technologies"; //can not directly change
(0, MyLibrary_1.changeLibrary)("Server Technologies");
var book1 = new MyLibrary_1.MyBook(567, 'javatech', 780);
book1.getDetails();
console.log(CollegeLibrary_1["default"]);
