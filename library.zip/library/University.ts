export class University{

}

export class Location{

}