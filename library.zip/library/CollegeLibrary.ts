let collegeName="LT college";
export class Department{

}
export default collegeName;
